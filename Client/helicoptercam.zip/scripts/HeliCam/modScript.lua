load("HeliCam")
setExtensionUnloadMode("HeliCam", "manual")

extensions.core_input_categories.helicam_mod = {
	order = 1,
	icon = "extension",
	title = "Helicam",
	desc = "Helicam Controls"
}